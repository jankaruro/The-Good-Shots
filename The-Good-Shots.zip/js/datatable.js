$(document).ready(function(){
    $('#user-management').DataTable();
});